# Spring Boot Login Demo

A simple login application built with Spring Boot to demonstrate how authentication works.

## What This Project Does

This is a learning example that shows how to:
- Create a login page where users enter their username and password
- Protect pages so only logged-in users can see them
- Show a personalized dashboard after login
- Let users log out safely

## Demo Credentials

Two test accounts are available:

| Username | Password | Role  |
|----------|----------|-------|
| kunal    | kunal    | USER  |
| admin    | admin    | ADMIN |

## How to Run

1. Make sure you have Java 17 installed
2. Open a terminal in this project folder
3. Run the application:
   ```
   mvn spring-boot:run
   ```
4. Open your browser and go to: http://localhost:8080
5. Log in with one of the demo accounts above

## Project Structure

```
src/main/java/com/example/logindemo/
├── LoginDemoApplication.java    # Main entry point
├── config/
│   └── SecurityConfig.java      # Security settings (users, login rules)
└── controller/
    ├── LoginController.java     # Handles the login page
    └── DashboardController.java # Handles the dashboard page

src/main/resources/
├── application.properties       # App configuration
└── templates/
    ├── login.html              # Login page design
    └── dashboard.html          # Dashboard page design
```

## Technologies Used

- **Java 17** - Programming language
- **Spring Boot 3.2** - Framework that makes building web apps easier
- **Spring Security** - Handles login, logout, and protecting pages
- **Thymeleaf** - Template engine for creating HTML pages
- **Maven** - Tool for building and running the project

## Customizing Credentials

You can change the demo usernames and passwords by setting environment variables:

```
export DEMO_USER_USERNAME=myuser
export DEMO_USER_PASSWORD=mypassword
export DEMO_ADMIN_USERNAME=myadmin
export DEMO_ADMIN_PASSWORD=myadminpassword
```

Or add them to `application.properties`:

```
demo.user.username=myuser
demo.user.password=mypassword
demo.admin.username=myadmin
demo.admin.password=myadminpassword
```

## Learning More

The code includes comments explaining what each part does. Start by reading:
1. `SecurityConfig.java` - How login and security are set up
2. `DashboardController.java` - How to get the logged-in user's info
3. `login.html` and `dashboard.html` - How the pages are built
