package com.example.logindemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main entry point for the Spring Boot Login Demo application.
 * 
 * The @SpringBootApplication annotation is a convenience annotation that combines:
 * - @Configuration: Marks this class as a source of bean definitions
 * - @EnableAutoConfiguration: Tells Spring Boot to automatically configure beans
 * - @ComponentScan: Tells Spring to scan for components in this package and subpackages
 * 
 * This application demonstrates:
 * - Spring Security with form-based login
 * - In-memory user authentication (no database required)
 * - Thymeleaf templates for server-side rendering
 * - Session management and logout functionality
 */
@SpringBootApplication
public class LoginDemoApplication {

    /**
     * Main method that starts the Spring Boot application.
     * 
     * SpringApplication.run() bootstraps the application by:
     * 1. Creating an ApplicationContext
     * 2. Registering a CommandLinePropertySource for command line arguments
     * 3. Refreshing the ApplicationContext to load all beans
     * 4. Starting the embedded web server (Tomcat by default)
     * 
     * @param args command line arguments passed to the application
     */
    public static void main(String[] args) {
        SpringApplication.run(LoginDemoApplication.class, args);
    }
}
