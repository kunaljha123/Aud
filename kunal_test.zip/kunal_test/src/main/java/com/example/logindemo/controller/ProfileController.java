package com.example.logindemo.controller;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller for handling the user profile page.
 * 
 * This controller displays a secured profile page that shows
 * information about the currently logged-in user. Like the dashboard,
 * this page requires authentication to access.
 */
@Controller
public class ProfileController {

    /**
     * Displays the profile page with the logged-in user's information.
     * 
     * The @AuthenticationPrincipal annotation automatically injects
     * the currently authenticated user's details. This allows us to
     * display user-specific information on the profile page.
     * 
     * @param userDetails the currently authenticated user (injected by Spring Security)
     * @param model the Model object to pass data to the view
     * @return the name of the profile template
     */
    @GetMapping("/profile")
    public String profile(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        // Add the username to the model
        model.addAttribute("username", userDetails.getUsername());
        
        // Add the user's roles/authorities to the model
        model.addAttribute("roles", userDetails.getAuthorities());
        
        return "profile";
    }
}
