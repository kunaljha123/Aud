package com.example.logindemo.controller;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller for handling dashboard-related requests.
 * 
 * This controller displays the dashboard page after successful login.
 * It demonstrates how to access the currently authenticated user's
 * information using Spring Security.
 */
@Controller
public class DashboardController {

    /**
     * Displays the dashboard page with the logged-in user's information.
     * 
     * The @AuthenticationPrincipal annotation automatically injects
     * the currently authenticated user's details. This is a convenient
     * way to access user information without manually querying the
     * SecurityContext.
     * 
     * @param userDetails the currently authenticated user (injected by Spring Security)
     * @param model the Model object to pass data to the view
     * @return the name of the dashboard template
     */
    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        // Add the username to the model so it can be displayed in the template
        model.addAttribute("username", userDetails.getUsername());
        
        // Add a welcome message to the model
        model.addAttribute("message", "Welcome to the Dashboard!");
        
        return "dashboard";
    }

    /**
     * Redirects the root URL to the dashboard.
     * 
     * When users access the application root (/), they will be
     * redirected to the dashboard. If not authenticated, Spring
     * Security will then redirect them to the login page.
     * 
     * @return redirect instruction to the dashboard
     */
    @GetMapping("/")
    public String home() {
        return "redirect:/dashboard";
    }
}
