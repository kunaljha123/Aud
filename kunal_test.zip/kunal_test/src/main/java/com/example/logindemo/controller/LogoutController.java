package com.example.logindemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller for handling logout confirmation.
 * 
 * This controller displays a confirmation page before logging out,
 * giving users a chance to cancel if they clicked logout by mistake.
 * The actual logout is still handled by Spring Security when the
 * user confirms by submitting the form on the confirmation page.
 */
@Controller
public class LogoutController {

    /**
     * Displays the logout confirmation page.
     * 
     * This page asks users "Are you sure you want to log out?"
     * and provides two options:
     * - Cancel: Returns to the dashboard
     * - Confirm: Submits to /logout which Spring Security handles
     * 
     * @return the name of the logout confirmation template
     */
    @GetMapping("/logout-confirm")
    public String logoutConfirm() {
        return "logout-confirm";
    }
}
