package com.example.logindemo.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Security Configuration for the Login Demo Application.
 * 
 * This class configures Spring Security to:
 * - Use form-based login with a custom login page
 * - Store users in memory (no database required)
 * - Protect the dashboard page (requires authentication)
 * - Allow public access to the login page
 * - Enable logout functionality
 * 
 * Demo credentials are configured via application.properties or environment variables.
 * Default values are provided for easy local development.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    // User credentials - can be overridden via environment variables or application.properties
    @Value("${demo.user.username:kunal}")
    private String userUsername;

    @Value("${demo.user.password:kunal}")
    private String userPassword;

    @Value("${demo.admin.username:admin}")
    private String adminUsername;

    @Value("${demo.admin.password:admin}")
    private String adminPassword;

    /**
     * Configures the security filter chain that defines how requests are secured.
     * 
     * @param http the HttpSecurity object to configure
     * @return the configured SecurityFilterChain
     * @throws Exception if configuration fails
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // Configure authorization rules for different URL patterns
            .authorizeHttpRequests(auth -> auth
                // Allow everyone to access the login page and static resources
                .requestMatchers("/login", "/css/**", "/js/**").permitAll()
                // All other requests require authentication
                .anyRequest().authenticated()
            )
            // Configure form-based login
            .formLogin(form -> form
                // Use our custom login page instead of Spring's default
                .loginPage("/login")
                // The URL where the login form submits (Spring Security handles this)
                .loginProcessingUrl("/login")
                // Where to redirect after successful login
                .defaultSuccessUrl("/dashboard", true)
                // Allow everyone to see the login page
                .permitAll()
            )
            // Configure logout functionality
            .logout(logout -> logout
                // URL to trigger logout
                .logoutUrl("/logout")
                // Where to redirect after logout
                .logoutSuccessUrl("/login?logout")
                // Invalidate the session on logout
                .invalidateHttpSession(true)
                // Delete the session cookie
                .deleteCookies("JSESSIONID")
                // Allow everyone to access logout
                .permitAll()
            );
        
        return http.build();
    }

    /**
     * Creates an in-memory user store with predefined users.
     * 
     * In a real application, you would use a database-backed UserDetailsService.
     * For this demo, we create two users stored in memory.
     * Credentials are configured via application.properties or environment variables:
     * - demo.user.username / demo.user.password (default: kunal/kunal)
     * - demo.admin.username / demo.admin.password (default: admin/admin)
     * 
     * @return UserDetailsService containing the in-memory users
     */
    @Bean
    public UserDetailsService userDetailsService() {
        // Create a regular user with USER role using configured credentials
        UserDetails user = User.builder()
            .username(userUsername)
            .password(passwordEncoder().encode(userPassword))
            .roles("USER")
            .build();

        // Create an admin user with ADMIN role using configured credentials
        UserDetails admin = User.builder()
            .username(adminUsername)
            .password(passwordEncoder().encode(adminPassword))
            .roles("ADMIN")
            .build();

        // Return an in-memory user manager with both users
        return new InMemoryUserDetailsManager(user, admin);
    }

    /**
     * Creates a password encoder for securely hashing passwords.
     * 
     * BCrypt is a strong hashing algorithm that includes a salt
     * and is designed to be slow, making brute-force attacks difficult.
     * 
     * @return BCryptPasswordEncoder for encoding passwords
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
