package com.example.logindemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller for handling login-related requests.
 * 
 * This controller is responsible for displaying the login page.
 * The actual login processing (form submission) is handled by
 * Spring Security, not by this controller.
 */
@Controller
public class LoginController {

    /**
     * Displays the login page.
     * 
     * This method handles GET requests to /login and returns the
     * name of the Thymeleaf template to render (login.html).
     * 
     * Spring Security will redirect unauthenticated users here
     * when they try to access protected resources.
     * 
     * @return the name of the login template
     */
    @GetMapping("/login")
    public String login() {
        return "login";
    }
}
